%% Matlab implementation for LBP-mapping as described in the following paper:
% Gil Levi and Tal Hassner, Emotion Recognition in the Wild via Convolutional Neural Networks and Mapped Binary Patterns, Proc. ACM International Conference on Multimodal Interaction (ICMI), Seattle, Nov. 2015 

% If you find our code usefull, please consider adding a suitable reference to our paper in your work. 


%% 
clc; clear; close all;
%% Calc  cyclic mapping

% calc distance matrix
cyclic_dist_matrix=zeros(256,256);
for ix=0:255
    ix_bin_vec = [0,de2bi(ix,8)];
    for jx=0:255
        jx_bin_vec = [0,de2bi(jx,8)];
        dist1=pdist2(ix_bin_vec,jx_bin_vec,'emd');
        dist2=pdist2(wrev(ix_bin_vec),jx_bin_vec,'emd');
        dist3=pdist2(ix_bin_vec,wrev(jx_bin_vec),'emd');
        cyclic_dist_matrix(ix+1,jx+1) = min([dist1,dist2,dist3]);
    end
end

%mds
Y=mdscale(cyclic_dist_matrix,3);
Y2=Y + abs(min(Y(:)));
Y2 = Y2 * (255/max(Y2(:)));
cyclic_map=uint8(Y2);



%% Calc regular mapping

% calc distance matrix
dist_matrix=zeros(256,256);
for ix=0:255
    ix_bin_vec = de2bi(ix,8);
    for jx=0:255
        jx_bin_vec = de2bi(jx,8);
        
        dist_matrix(ix+1,jx+1) = pdist2(ix_bin_vec,jx_bin_vec,'emd');
    end
end

%mds
Y=mdscale(dist_matrix,3);
Y2=Y + abs(min(Y(:)));
Y2 = Y2 * (255/max(Y2(:)));
regular_map=uint8(Y2);



%% Calculating representations

im=imread('example_image.png');
figure; imshow(im); title('original image');


lbp_mapping=getmapping(8,'reg');
im_gray = rgb2gray(im);

H1=lbp(im_gray,1,8,lbp_mapping,'reg');
mds_im = regular_map(H1+1,:);
out_im = reshape(mds_im,[size(H1) 3]);
figure; imshow(out_im); title('regular LBP');

mds_im = cyclic_map(H1+1,:);
out_im = reshape(mds_im,[size(H1) 3]);
figure; imshow(out_im); title('cyclic LBP');



H1=lbp(im_gray,5,8,lbp_mapping,'reg');
mds_im = cyclic_map(H1+1,:);
out_im = reshape(mds_im,[size(H1) 3]);
figure; imshow(out_im); title('cyclic LBP 5');

H1=lbp(im_gray,10,8,lbp_mapping,'reg');
mds_im = cyclic_map(H1+1,:);
out_im = reshape(mds_im,[size(H1) 3]);
figure; imshow(out_im); title('cyclic LBP 10');


