#/bin/sh
LIBS_PREFIX=/home/liav/code/openu/hypothesis_relevancy_ransac/local
env LD_LIBRARY_PATH=$LIBS_PREFIX/Mesa-7.0.3/lib64/:$LIBS_PREFIX/lib64/osgPlugins-2.8.1/:$LIBS_PREFIX/lib64:$LIBS_PREFIX/lib matlab
