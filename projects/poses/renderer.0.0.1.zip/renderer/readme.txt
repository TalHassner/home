Mesh renderer code - source code for a C++ mesh renderer to be used from MATLAB (mex file) using OpenSceneGraph
------------------
This code renders textured 3D models (standard 3D file formats), using either sphere orientation (elevation , azimuth, and yaw) or camera matrix. 
Its output includes a rendered view of the textured model and its corresponding depth-map (inverse depth at each pixel). In addition, it provides an 'unproject' matrix which associates each pixel with the coordinates the 3D surface point projected onto that pixel.  
The result is not rendered on screen but returned to MATLAB as a matrix or saved directly to file. This makes the program suitable to be run on console versions of MATLAB, without a physical display screen, as well as in batch mode, in order to process many views / models directly from MATLAB.
OpenGL is used as the backend. On Linux the Mesa (software) OpenGL implementation was used so no special hardware is required.

This code was developed by Liav Assif and Tal Hassner, and was used in the following papers: 

T. Hassner, Viewing Real-World Faces in 3D, International Conference on Computer Vision (ICCV), Sydney, Austraila, Dec. 2013
T. Hassner, L. Assif, and L. Wolf, When Standard RANSAC is Not Enough: Cross-Media Visual Matching with Hypothesis Relevancy, Machine Vision and Applications (MVAP), to appear 

If you find this code useful, please add suitable references in your work to either (or both) of these papers.

The code is available from:
http://www.openu.ac.il/home/hassner/projects/poses

Copyright 2013, Liav Assif and Tal Hassner

The SOFTWARE ("renderer" and \ or  "calib") is provided "as is", without any guarantee made as to its suitability or fitness for any particular use.  It may contain bugs, so use of this tool is at your own risk. We take no responsibility for any damage that may unintentionally be caused through its use. The code makes use of the OpenCV and the OpenSceneGraph libraries. Any use of this code must respect their respective licenses.

Dependencies:
1. OpenSceneGraph, a high performance 3D graphics toolkit
http://www.openscenegraph.org/

2. OpenCV
http://opencv.org/

The code depends on OpenSceneGraph (2.8.0), OpenCV (1.1 or above) and OpenGL. 
It was tested and run on MATLAB releases 2009b and 2012a on Linux. However there are no Linux dependencies in the code so minor changes could be made to make it run on Windows.

When compiling using MATLAB 'mex', the library path to these libraries can be provided using -L, e.g. if they are stored locally in ../local then:
mex renderer/renderer.cpp renderer/Camera.cpp renderer/depth.cpp renderer/Engine.cpp renderer/EngineOSG.cpp util/util.cpp -lcv -lcxcore -lGL -lX11 -losg -losgViewer -losgDB -losgGA -losgUtil -lOpenThreads -lGLU -Iutil/ -L../local/lib -L../local/lib64 -I../local/include

The supported mesh files are the formats supported by OpenSceneGraph. Existing mesh files (e.g. .3DS, .WRL.) can be loaded by the renderer but best results are achieved by first exporting the mesh files to COLLADA DOM (from .3DS, Google Sketchup format etc.) and then using OpenSceneGraph utilities (osgconv) to convert to its own .OSG format. Then supplying the resulting .OSG file to the renderer.

renderer usage:
	[depth_image, rendered_image, unproject, out_A, out_R, out_T, out_vertices, out_colors, out_colors_binding, out_normals, out_normals_binding]
	= renderer(width, height, filename, writefiles, lighting, sphere orientation (4 arguments)/camera orientation (3-4 arguments), in_vertices, in_colors, in_colors_binding, in_normals , in_normals_binding)
Most input and output parameters are optional.
width and height should be unsigned integers.
filename - the input mesh filename. out_vertices, colors and normals will only be returned from a version 1.0 VRML file.
	Other file types are supported for the rest of the operations.
writefiles should be 0 or 1.
lighting should be 0 (disabled) or 1 (enabled).
sphere orientation are the following 4 arguments: distance, elevation , azimuth and yaw.
distance - a number added to the (auto calculated) model's bounding sphere radius. 0 is usually suitable.
elevation, azimuth and yaw are degrees. The camera position on the bounding sphere is specified using them.
camera orientation are 3 arguments: A, R and T. Add an additional dummy argument (e.g. 0) if further input parameters are specified. 
in_vertices - an M x 3 matrix with real values. If the matrix is not empty then it is used instead of a file (even if a filename is supplied).
	 Each row is a vertex (x,y,z). Every three rows forms a triangle.
in_colors - an M x 4 matrix with real values. Not necessarily the same M of as of in_vertices.
in_colors_binding - an integer specifing the colors binding type.
in_normals - an M x 3 matrix with real values. Not necessarily the same M as of in_vertices.
in_normals_binding - an integer specifing the normals binding type.
Examples:
renderer(300,300,'file.wrl');
[depth, rendered]=renderer(300, 300, 'file.wrl');
[depth, rendered, unproject, A, R, T, verts, cols, cbind, nors, nbind]=renderer(300, 300, 'file.wrl');
Now 'unproject(125,149,1:3)' returns the world XYZ coordinate of the image point (x=148,y=124)
Now it is possible to use the output of the previous command as the input for the following one:
[depth, rendered]=renderer(300, 300, '', 0, 0, 0, 0, 0, 0, verts, cols, cbind, nors, nbind);
[depth, rendered, unproject, A, R, T]=renderer(300, 300, 'file.wrl',0,0.5,10,20,30);
Renders the mesh with a distance of 0.5, an elevation of 10 degrees, azimuth of 20 degrees and yaw of 30 degrees. Next
[depth, rendered, unproject]=renderer(300, 300, 'file.wrl',0,A,R,T);
Will yield the same results.