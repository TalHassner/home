This is an implementation and demo of the Scale-Less SIFT descriptors (SLS) described in the paper:

 Tal Hassner, Viki Mayzels, and Lihi Zelnik-Manor,
    "On SIFTs and their Scales",
    IEEE Conf. on Computer Vision and Pattern Recognition (CVPR),
    Rhode Island, June 2012
    http://www.openu.ac.il/home/hassner/projects/siftscales/

Please cite the paper if you use this code for your research.

This distribution includes MATLAB Code for computing dense Scale-Less SIFT descriptors for a pair of images.
The demo script demonstrates how these can be used to compute dense correspondences between two images. 
compute_dense_flow is a functional version of the demo.

11-June-2012, Version 1.1 
  What's new:
  The code now includes an option to compute SLS descriptors with PCA reduced SIFTs. This produces SLS descriptors which 
  are an order of magnitude smaller than those used in the paper, while still providing high quality dense flows. 
  A more detailed description of this addition will be described in an upcoming paper.   
  See the help for extract_scalelessdescs for more information on the new usage options.


Installing and Running
1. Install instructions
	The code uses the vlfeat distribution to compute SIFT descriptors and the SIFT-Flow release for computing 
	dense correspondences. Please follow these instructions to set these up before running our code.
	
	Download the following software to your computer and modify the the following lines in demo.m and compute_dense_flow.m
    - The vl_feat distribution from http://www.vlfeat.org/  
      In the line "addpath vlfeat-0.9.14/toolbox" - replace "vlfeat-0.9.14" with the name of the folder 
      containing the vl_feat code.
     
    - The Sift-flow distribution from http://people.csail.mit.edu/celiu/ECCV2008/
      In the lines "addpath release" and "addpath release/mex" - replace "release" with the name 
      of the folder containing the SIFT-flow code.
     
2.  To run the algorithm on an example image pair, included in the distribution, run the script demo.m. To use 
    your own images or to modify parameters, see the help in:
        help demo
        help extract_scalelessdescs

3.  Alternatively, to run the demo as a function, you can call:
    [flo,wrp,clrflo] = compute_dense_flow(Im_Source, Im_Target)
    wrp provides warped output images such as those shown in the paper.
    For more information, see
        help compute_dense_flow

3.  Please note that this code was not designed for optimal running times or memory usage. It may therefore require 
    quite a lot of time to produce multiple SIFTs for each pixel and compute subspaces, as require a lot of memory for 
    the descriptors produced at each pixel.
   

Copyright 2012, Tal Hassner, Viki Mayzels, Shay Filosof, and Lihi Zelnik-Manor
http://www.openu.ac.il/home/hassner/projects/siftscales/
 

The SOFTWARE ("extract_scalelessdescs", "compute_dense_flow" and "demo.m") is provided "as is", without any
guarantee made as to its suitability or fitness for any particular use. 
It may contain bugs, so use of this tool is at your own risk.
We take no responsibility for any damage that may unintentionally be caused
through its use.
 
ver 1.1, 11-June-2012

